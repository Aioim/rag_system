"""共享枚举类型"""
from enum import Enum


class Intent(str, Enum):
    CONCEPT = "concept"
    PROCEDURE = "procedure"
    COMPARE = "compare"
    LOOKUP = "lookup"


class RetrievalEval(str, Enum):
    SUFFICIENT = "sufficient"
    NEED_MORE = "need_more"
    INSUFFICIENT = "insufficient"


class DocumentStatus(str, Enum):
    PENDING = "pending"
    PARSING = "parsing"
    CHUNKING = "chunking"
    EMBEDDING = "embedding"
    DONE = "done"
    FAILED = "failed"
